figma.showUI(__html__, { width: 600, height: 600 });

figma.ui.onmessage = async(msg) => {
    if (msg.type === 'add-animation') {
        try {
            const animation = msg.animation;
            console.log("Animation received:", animation);

            // Load required font
            await figma.loadFontAsync({ family: "Inter", style: "Bold" });

            // Create outer frame 32x32
            const frame = figma.createFrame();
            frame.resize(32, 32);
            frame.name = `Ripplix: ${animation.title || 'Animation'}`;
            frame.layoutMode = "NONE";
            frame.fills = [];

            // Load and insert the SVG
            const svgURL = animation.logoUrl || "https://www.ripplix.com/wp-content/uploads/2025/04/Logo-figma.svg";
            const svgFetch = await fetch(svgURL);
            const svgText = await svgFetch.text();
            const svgNode = figma.createNodeFromSvg(svgText);

            // Center the SVG inside the frame
            svgNode.x = (32 - svgNode.width) / 2;
            svgNode.y = (32 - svgNode.height) / 2;
            frame.appendChild(svgNode);

            // Create an almost invisible clickable text layer (must be visible to register hyperlink)
            const textNode = figma.createText();
            textNode.fontName = { family: "Inter", style: "Bold" };
            textNode.characters = "R"; // use "R" instead of space
            textNode.fontSize = 1;
            textNode.opacity = 0.001; // barely visible
            textNode.resize(32, 32); // full frame size
            textNode.textAlignHorizontal = "CENTER";
            textNode.textAlignVertical = "CENTER";
            textNode.fills = [{ type: 'SOLID', color: { r: 1, g: 1, b: 1 } }];
            textNode.hyperlink = { type: "URL", value: animation.url };
            textNode.x = 0;
            textNode.y = 0;
            frame.appendChild(textNode);

            // Position in viewport
            frame.x = figma.viewport.center.x - 16;
            frame.y = figma.viewport.center.y - 16;

            figma.currentPage.appendChild(frame);
            figma.currentPage.selection = [frame];

            // Store metadata
            frame.setPluginData('animationUrl', animation.url);
            frame.setPluginData('animationTitle', animation.title || '');

            // Notify UI
            figma.ui.postMessage({
                type: 'animation-added',
                success: true,
                message: "Ripplix logo added with full clickable area."
            });
        } catch (error) {
            console.error("Error:", error);
            figma.ui.postMessage({
                type: 'animation-added',
                success: false,
                error: error.message || "Failed to add animation"
            });
        }
    }

    if (msg.type === 'close-plugin') {
        figma.closePlugin();
    }
};

// Plugin ready
figma.ui.postMessage({
    type: 'plugin-ready'
});