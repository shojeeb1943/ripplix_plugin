// This plugin will allow users to browse and add Ripplix animations to Figma designs
// The plugin provides functionality to view animations and add them as links

// Show the main UI
console.log("Opening main animation library UI");
figma.showUI(__html__, { width: 600, height: 600 });

// Handle messages from the UI
figma.ui.onmessage = async(msg) => {
    if (msg.type === 'add-animation') {
        // Add animation to Figma
        try {
            // Create a text node with the animation title
            const textNode = figma.createText();
            await figma.loadFontAsync({ family: "Inter", style: "Regular" });
            textNode.characters = msg.animation.title;

            // Create a hyperlink
            textNode.hyperlink = { type: "URL", value: msg.animation.url };

            // Position at the center of the viewport
            textNode.x = figma.viewport.center.x - textNode.width / 2;
            textNode.y = figma.viewport.center.y;

            // Select the created node
            figma.currentPage.selection = [textNode];

            // Notify the UI
            figma.ui.postMessage({
                type: 'animation-added',
                success: true,
                message: 'Animation added successfully!'
            });
        } catch (error) {
            console.error('Error adding animation:', error);
            figma.ui.postMessage({
                type: 'animation-added',
                success: false,
                error: error.message || 'Failed to add animation'
            });
        }
    } else if (msg.type === 'close-plugin') {
        figma.closePlugin();
    }
};

// Notify the UI that the plugin is ready
figma.ui.postMessage({
    type: 'plugin-ready'
});